Premier League Predictions - LIVE TEST BUILD

Upload this folder to a static host such as Netlify Drop.

After publishing, copy the final HTTPS site URL. In Supabase Dashboard > Authentication > URL Configuration, set the Site URL to that exact HTTPS URL and add the same URL as an allowed Redirect URL. Then return to ChatGPT with the public URL.

Launch rules currently in the database:
- Joining closes Friday 21 August 2026 at 15:00 UK time.
- All Matchweek 1 predictions lock Friday 21 August 2026 at 17:00 UK time.
- Later fixtures: open 7 days before kickoff and normally lock at 11:00am on matchday.
- Exact score = 3 points; correct outcome = 1; wrong = 0.
- Every active member can create/share an invite until the joining deadline.
- James/admin enters results manually for the first test.
